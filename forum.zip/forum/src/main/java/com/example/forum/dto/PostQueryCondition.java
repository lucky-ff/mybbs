package com.example.forum.dto;

import lombok.Data;

/**
 * @description: 文章格式封装类
 * @author: kongbai
 * @date: 2020-04-05 14:41
 **/

@Data
public class PostQueryCondition {

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 标签ID
     */
    private Long tagId;

    /**
     * 板块ID
     */
    private Long cateId;

    /**
     * 关键字
     */
    private String keywords;

}
