package com.example.forum.enums;

/**
 * @description: 角色类型
 * @author: kongbai
 * @date: 2020-04-08 13:31
 **/

public enum RoleEnum {

    /**
     * 管理员
     */
    ADMIN("admin"),

    /**
     * 普通用户
     */
    USER("user"),

    /**
     * 学校负责人
     */
    UNIVERSITY_USER("university_user");

    private String value;

    RoleEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
