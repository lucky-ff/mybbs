package com.example.forum.service;

import com.example.forum.common.base.BaseService;
import com.example.forum.entity.UserRoleRef;

/**
 * @description: 用户角色管理业务逻辑接口
 * @author: kongbai
 * @date: 2020-04-07 17:21
 **/

public interface UserRoleRefService extends BaseService<UserRoleRef, Long> {

    /**
     * 根据用户Id删除
     *
     * @param userId 用户Id
     */
    void deleteByUserId(Long userId);

}
