package com.example.forum.exception;

/**
 * @description: 网页状态码
 * @author: kongbai
 * @date: 2020-04-08 15:20
 **/

public class MyBusinessException extends RuntimeException {

    private Integer code;

    private String message;


    public MyBusinessException() {
        super();
    }

    public MyBusinessException(String message) {
        this.code = 500;
        this.message = message;
    }

    public MyBusinessException(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
