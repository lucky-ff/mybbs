package com.example.forum.service;

import com.example.forum.entity.RolePermissionRef;

import java.util.List;

/**
 * @description: 角色权限关联管理业务逻辑接口
 * @author: kongbai
 * @date: 2020-04-07 17:18
 **/

public interface RolePermissionRefService {

    /**
     * 删除某个角色的所有关联
     *
     * @param roleId 角色Id
     */
    void deleteRefByRoleId(Long roleId);

    /**
     * 添加角色和权限关联
     *
     * @param rolePermissionRef RolePermissionRef
     * @return UserRoleRef
     */
    void saveByRolePermissionRef(RolePermissionRef rolePermissionRef);

    /**
     * 批量添加
     *
     * @param rolePermissionRefs 列表
     */
    void batchSaveByRolePermissionRef(List<RolePermissionRef> rolePermissionRefs);

}
