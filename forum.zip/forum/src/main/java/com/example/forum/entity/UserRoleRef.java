package com.example.forum.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.example.forum.common.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description: 用户角色关联实体类
 * @author: kongbai
 * @date: 2020-04-05 14:23
 **/

@EqualsAndHashCode(callSuper = true)
@Data
@TableName("user_role_ref")
public class UserRoleRef extends BaseEntity {

    /**
     * 用户Id
     */
    private Long userId;

    /**
     * 角色Id
     */
    private Long roleId;

    public UserRoleRef(Long userId, Long roleId) {
        this.userId = userId;
        this.roleId = roleId;
    }

    public UserRoleRef() {
    }

}
