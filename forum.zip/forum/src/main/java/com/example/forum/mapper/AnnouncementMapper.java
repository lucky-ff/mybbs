package com.example.forum.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.forum.entity.Announcement;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description: 公告
 * @author: kongbai
 * @date: 2020-04-10 15:30
 **/

@Mapper
public interface AnnouncementMapper extends BaseMapper<Announcement> {

}
