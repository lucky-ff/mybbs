package com.example.forum.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.example.forum.common.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description: 标签实体类
 * @author: kongbai
 * @date: 2020-04-05 14:20
 **/

@EqualsAndHashCode(callSuper = true)
@Data
@TableName("tag")
public class Tag extends BaseEntity {

    /**
     * 标签名称
     */
    private String tagName;


    /**
     * 数量
     */
    @TableField(exist = false)
    private Integer count;
}
