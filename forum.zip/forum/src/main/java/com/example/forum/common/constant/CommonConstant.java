package com.example.forum.common.constant;

/**
 * @description: 常量
 * @author: kongbai
 * @date: 2020-04-05 11:07
 **/

public interface CommonConstant {

    /**
     * 正常状态
     */
    Integer STATUS_NORMAL = 0;

    /**
     * 用户密码加盐的盐
     */
    String PASSWORD_SALT = "sens";

    /**
     * none
     */
    String NONE = "none";
}
