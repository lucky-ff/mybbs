package com.example.forum.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.example.forum.common.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @description: 权限实体表(后台权限菜单)
 * @author: kongbai
 * @date: 2020-04-05 13:59
 **/

@EqualsAndHashCode(callSuper = true)
@Data
@TableName("permission")
public class Permission extends BaseEntity {

    /**
     * 权限名称
     */
    private String name;

    /**
     * pid
     */
    private Long pid;

    /**
     * 资源类型
     */
    private String resourceType;

    /**
     * 请求URL
     */
    private String url;

    /**
     * 图标
     */
    private String icon;

    /**
     * 序号(越小越靠前)
     */
    private Double sort;

    /**
     * 级别
     */
    @TableField(exist = false)
    private Integer level;

    /**
     * 子权限列表
     */
    @TableField(exist = false)
    private List<Permission> childPermissions;

}
