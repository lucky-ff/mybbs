package com.example.forum.service;

import javax.mail.MessagingException;

/**
 * @description: 邮件发送业务逻辑接口
 * @author: kongbai
 * @date: 2020-04-07 17:13
 **/

public interface MailService {

    /**
     * 发送邮件
     *
     * @param to      接收者
     * @param title   标题
     * @param content 内容
     */
    void sendMail(String to, String title, String content) throws MessagingException;

}
