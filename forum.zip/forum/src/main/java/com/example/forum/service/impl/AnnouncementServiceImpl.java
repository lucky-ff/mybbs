package com.example.forum.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.forum.entity.Announcement;
import com.example.forum.mapper.AnnouncementMapper;
import com.example.forum.service.AnnouncementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @description: 公告业务逻辑实现类
 * @author: kongbai
 * @date: 2020-04-10 15:41
 **/

@Service
public class AnnouncementServiceImpl implements AnnouncementService {

    @Autowired(required = false)
    private AnnouncementMapper announcementMapper;

    @Override
    public BaseMapper<Announcement> getRepository() {
        return announcementMapper;
    }

    @Override
    public QueryWrapper<Announcement> getQueryWrapper(Announcement announcement) {
        //对指导字段进行查询
        QueryWrapper<Announcement> queryWrapper = new QueryWrapper<>();
        if(announcement != null){
            if(StrUtil.isNotBlank(announcement.getAnContent())){
                queryWrapper.like("an_content",announcement.getAnContent());
            }
        }
        return queryWrapper;
    }

    @Override
    public Announcement insertOrUpdate(Announcement entity) {
        if (entity.getId() == null) {
            insert(entity);
        } else {
            update(entity);
        }
        return entity;
    }

    @Override
    public void delete(Long id) {
        announcementMapper.deleteById(id);
    }

    @Override
    public List<Announcement> findAll() {
        List<Announcement> announcementList = announcementMapper.selectList(null);
        return announcementList;
    }
}
