package com.example.forum.service;

import com.example.forum.common.base.BaseService;
import com.example.forum.entity.Announcement;

/**
 * @description: 公告业务接口
 * @author: kongbai
 * @date: 2020-04-10 15:39
 **/

public interface AnnouncementService extends BaseService<Announcement,Long> {

}
