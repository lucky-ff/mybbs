package com.example.forum.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @description: 模板渲染引擎层传输的对象
 * @author: kongbai
 * @date: 2020-04-05 11:28
 **/

@Data
public class SearchVo implements Serializable {
    /**
     * 起始日期
     */
    private String startDate;

    /**
     * 结束日期
     */
    private String endDate;
}
