package com.example.forum.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.example.forum.common.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description: 公告实体类
 * @author: kongbai
 * @date: 2020-04-10 15:18
 **/

@EqualsAndHashCode(callSuper = true)
@Data
@TableName("announcement")
public class Announcement extends BaseEntity {

    /**
     * 公告内容
     */
    private String anContent;
}
