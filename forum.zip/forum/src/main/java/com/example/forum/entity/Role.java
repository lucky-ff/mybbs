package com.example.forum.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.example.forum.common.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @description: 角色实体类
 * @author: kongbai
 * @date: 2020-04-05 14:17
 **/

@EqualsAndHashCode(callSuper = true)
@Data
@TableName("role")
public class Role extends BaseEntity {

    /**
     * 角色名称：admin，author，subscriber
     */
    private String role;

    /**
     * 描述：管理员，作者，订阅者
     */
    private String description;

    /**
     * 级别
     */
    private Integer level;

    /**
     * 用户注册默认角色
     */
    private Integer isRegisterDefault;

    /**
     * 该角色对应的用户数量，非数据库字段
     */
    @TableField(exist = false)
    private Integer count;

    /**
     * 当前角色的权限列表
     */
    @TableField(exist = false)
    private List<Permission> permissions;
}
