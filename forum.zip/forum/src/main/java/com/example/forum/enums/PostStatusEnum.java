package com.example.forum.enums;

/**
 * @description: 文章状态
 * @author: kongbai
 * @date: 2020-04-08 13:26
 **/

public enum PostStatusEnum {

    /**
     * 已发布
     */
    PUBLISHED(0),

    /**
     * 草稿
     */
    DRAFT(1),

    /**
     * 回收站
     */
    RECYCLE(2),

    /**
     * 待审核
     */
    CHECKING(3);

    private Integer code;

    PostStatusEnum(Integer code) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }

}
