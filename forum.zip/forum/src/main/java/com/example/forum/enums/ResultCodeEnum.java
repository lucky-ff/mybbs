package com.example.forum.enums;

/**
 * @description: 返回结果
 * @author: kongbai
 * @date: 2020-04-08 13:28
 **/

public enum ResultCodeEnum {

    /**
     * 成功
     */
    SUCCESS(1),

    /**
     * 失败
     */
    FAIL(0);

    Integer code;

    ResultCodeEnum(Integer code) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }

}
