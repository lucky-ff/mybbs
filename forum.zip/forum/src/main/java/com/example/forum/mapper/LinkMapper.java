package com.example.forum.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.forum.entity.Link;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description: 友情链接
 * @author: kongbai
 * @date: 2020-04-08 13:51
 **/

@Mapper
public interface LinkMapper extends BaseMapper<Link> {


}
