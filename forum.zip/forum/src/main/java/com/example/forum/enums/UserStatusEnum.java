package com.example.forum.enums;

/**
 * @description: 用户状态
 * @author: kongbai
 * @date: 2020-04-08 13:36
 **/

public enum UserStatusEnum {

    /**
     * 正常
     */
    NORMAL(0),

    /**
     * 禁止登录
     */
    BAN(1);


    private Integer code;

    UserStatusEnum(Integer code) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }

}
