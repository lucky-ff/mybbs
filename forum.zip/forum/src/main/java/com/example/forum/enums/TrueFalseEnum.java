package com.example.forum.enums;

/**
 * @description: True or False
 * @author: kongbai
 * @date: 2020-04-08 13:35
 **/

public enum TrueFalseEnum {

    /**
     * 真
     */
    TRUE("true"),

    /**
     * 假
     */
    FALSE("false");

    private String value;

    TrueFalseEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
