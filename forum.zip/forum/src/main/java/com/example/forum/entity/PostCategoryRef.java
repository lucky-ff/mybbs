package com.example.forum.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.example.forum.common.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description: 帖子板块关联实体表
 * @author: kongbai
 * @date: 2020-04-05 14:03
 **/

@EqualsAndHashCode(callSuper = true)
@Data
@TableName("post_category_ref")
public class PostCategoryRef extends BaseEntity {

    private static final long serialVersionUID = 1138370462094725857L;
    /**
     * 帖子Id
     */
    private Long postId;

    /**
     * 板块Id
     */
    private Long cateId;

    public PostCategoryRef(Long postId, Long cateId) {
        this.postId = postId;
        this.cateId = cateId;
    }

    public PostCategoryRef() {
    }

}
