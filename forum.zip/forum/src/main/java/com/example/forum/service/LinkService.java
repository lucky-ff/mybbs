package com.example.forum.service;

import com.example.forum.common.base.BaseService;
import com.example.forum.entity.Link;

/**
 * @description: 友情链接业务逻辑接口
 * @author: kongbai
 * @date: 2020-04-07 17:11
 **/

public interface LinkService extends BaseService<Link, Long> {

}
