package com.example.forum.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.example.forum.common.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description: 板块实体类
 * @author: kongbai
 * @date: 2020-04-05 13:48
 **/

@EqualsAndHashCode(callSuper = true)
@Data
@TableName("category")
public class Category extends BaseEntity {

    /**
     * 板块名称
     */
    private String cateName;

    /**
     * 板块排序号
     */
    private Integer cateSort;

    /**
     * 板块描述
     */
    private String cateDesc;
}
