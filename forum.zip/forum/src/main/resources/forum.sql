/*
 Navicat Premium Data Transfer

 Source Server         : mysql57
 Source Server Type    : MySQL
 Source Server Version : 50721
 Source Host           : localhost:3306
 Source Schema         : forum

 Target Server Type    : MySQL
 Target Server Version : 50721
 File Encoding         : 65001

 Date: 24/04/2020 16:51:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for announcement
-- ----------------------------
DROP TABLE IF EXISTS `announcement`;
CREATE TABLE `announcement`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '公告id',
  `an_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '公告内容',
  `del_flag` int(1) NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '发布人用户名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '发表时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新人用户名',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of announcement
-- ----------------------------

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '板块唯一id',
  `cate_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '板块名称',
  `cate_sort` int(11) NOT NULL DEFAULT 1 COMMENT '板块排序号',
  `cate_desc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '板块描述',
  `del_flag` int(1) NOT NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  `create_by` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人用户名',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_by` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新人用户名',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (1, 'A校', 100, 'A类学校', 0, NULL, '2020-04-13 14:32:57', NULL, '2020-04-13 14:33:05');
INSERT INTO `category` VALUES (2, 'B校', 90, 'B类学校', 0, NULL, '2020-04-13 14:33:45', NULL, '2020-04-13 14:33:48');
INSERT INTO `category` VALUES (3, 'C校', 80, 'C类学校', 0, NULL, '2020-04-13 14:34:18', NULL, '2020-04-14 09:46:33');
INSERT INTO `category` VALUES (4, 'D校', 70, 'D类学校', 0, NULL, '2020-04-13 14:34:45', NULL, '2020-04-14 09:46:35');
INSERT INTO `category` VALUES (5, 'E校', 60, 'E类学校', 0, NULL, '2020-04-13 14:35:26', NULL, '2020-04-14 09:46:38');
INSERT INTO `category` VALUES (6, 'F校', 50, 'F类学校', 0, NULL, '2020-04-13 14:35:48', NULL, '2020-04-14 09:46:41');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '这条评论唯一id',
  `post_id` bigint(20) NOT NULL COMMENT '被评论的帖子id',
  `user_id` bigint(20) NOT NULL COMMENT '发表评论的用户id',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '发表的内容',
  `comment_parent` bigint(20) NOT NULL COMMENT '判断是评论还是回复',
  `path_trace` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '关系结构',
  `accept_user_id` bigint(20) NOT NULL DEFAULT 0 COMMENT '接收人的id',
  `like_count` int(11) NOT NULL DEFAULT 0 COMMENT '点赞数',
  `dislike_count` int(11) NOT NULL DEFAULT 0 COMMENT '点踩数',
  `is_read` int(1) NOT NULL DEFAULT 0 COMMENT '是否阅读：1是，0否',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'admin' COMMENT '创建人用户名',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'admin' COMMENT '更新人用户名',
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `del_flag` int(11) NOT NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_Relationship_11`(`post_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES (1, 11, 1, '哈哈123456', 0, '/', 1, 1, 1, 1, 'admin', '2020-04-24 15:24:47', 'admin', '2020-04-24 15:24:48', 0);

-- ----------------------------
-- Table structure for link
-- ----------------------------
DROP TABLE IF EXISTS `link`;
CREATE TABLE `link`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '友情链接id',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '友情链接名称',
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '友情链接网址',
  `link_pic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '链接头像',
  `link_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '友情链接描述',
  `del_flag` int(1) NOT NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人用户名',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新人用户名',
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of link
-- ----------------------------

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '权限id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '权限名称',
  `pid` bigint(20) NOT NULL COMMENT '上一级权限id',
  `resource_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '资源类型',
  `url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '请求url',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '权限图标',
  `sort` double(11, 0) NULL DEFAULT 1 COMMENT '权限排序号(越小越靠前)',
  `del_flag` int(1) NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'admin' COMMENT '创建人用户名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'admin' COMMENT '更新人用户名',
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 161 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of permission
-- ----------------------------
INSERT INTO `permission` VALUES (1, '首页', 0, 'menu', '/admin', 'fa fa-dashboard', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (3, '日志列表', 1, 'button', '/admin/logs', NULL, 3, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (4, '博客介绍', 1, 'button', '/admin/sens', NULL, 4, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (5, '清空日志', 116, 'button', '/admin/log/clear', '', 5, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (6, '获得侧边栏菜单', 1, 'button', '/admin/currentMenus', '', 6, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (7, '退出登录', 1, 'button', '/admin/logOut', '', 7, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (70, '用户管理', 0, 'menu', '/admin/user', 'fa fa-user', 80, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (71, '用户列表', 70, 'menu', '/admin/user', 'fa fa-circle-o', 71, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (72, '添加用户', 70, 'menu', '/admin/user/new', 'fa fa-circle-o', 72, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (73, '用户保存', 70, 'button', '/admin/user/save', NULL, 73, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (74, '删除用户', 70, 'button', '/admin/user/delete', NULL, 74, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (75, '批量删除用户', 70, 'button', '/admin/user/batchDelete', NULL, 75, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (76, '编辑用户', 70, 'button', '/admin/user/edit', '', 76, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (80, '个人信息', 70, 'button', '/admin/user/profile', '', 80, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (81, '删除绑定', 70, 'button', '/admin/user/deleteBind', NULL, 81, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (82, '保存个人信息', 120, 'button', '/admin/user/profile/save', '', 82, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (83, '修改密码', 120, 'button', '/admin/user/changePass', '', 83, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (91, '角色管理', 0, 'menu', '/admin/role', 'fa fa-snowflake-o', 91, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (92, '保存角色', 91, 'button', '/admin/role/save', '', 92, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (93, '编辑角色', 91, 'page', '/admin/role/edit', '', 93, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (94, '删除角色', 91, 'button', '/admin/role/delete', '', 94, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (95, '权限管理', 0, 'menu', '#', 'fa fa-podcast', 95, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (96, '保存权限', 95, 'button', '/admin/permission/save', '', 96, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (97, '编辑权限', 95, 'page', '/admin/permission/edit', '', 97, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (98, '删除权限', 95, 'button', '/admin/permission/delete', '', 98, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (106, '获得当前登录用户信息接口', 1, 'button', '/admin/currentUser', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (109, '组织管理', 0, 'menu', '/admin/organization', 'fa fa-building', 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (110, '添加权限', 95, 'menu', '/admin/permission/new', 'fa fa-circle-o', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (111, '添加角色', 91, 'menu', '/admin/role/new', 'fa fa-circle-o', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (112, '添加组织', 109, 'menu', '/admin/organization/new', 'fa fa-circle-o', 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (113, '保存组织', 109, 'button', '/admin/organization/save', '', 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (114, '编辑组织', 109, 'button', '/admin/organization/edit', '', 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (115, '删除组织', 109, 'button', '/admin/organization/delete', '', 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (116, '日志管理', 0, 'menu', '/admin/log', 'fa fa-eye', 100, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (117, '删除日志', 116, 'button', '/admin/log/delete', '', 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (118, '获得所有权限列表', 95, 'page', '/admin/permission/list', '', 100, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (119, '根据角色ID获得权限列表', 91, 'button', '/admin/role/permission', '', 100, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (120, '个人信息', 0, 'page', '/admin/user/profile', '', 99, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (121, '111', 0, 'button', '11', NULL, 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (122, '2211', 0, 'button', '1', NULL, 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (123, '11', 0, 'page', '1', NULL, 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (124, '1111111', 123, 'button', '11', NULL, 1, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (125, '1', 0, 'button', '1', NULL, 11, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (126, '用户列表', 70, 'menu', '/admin/user', 'fa fa-circle-o', 0, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (127, '角色列表', 91, 'menu', '/admin/role', 'fa fa-circle-o', 0, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (128, '权限列表', 95, 'menu', '/admin/permission', 'fa fa-circle-o', 0, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (129, '组织列表', 116, 'menu', '/admin/organization', NULL, 11, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (130, '组织列表', 109, 'menu', '/admin/organization', 'fa fa-circle-o', 0, 1, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (131, '帖子管理', 0, 'menu', '/admin/post', 'fa fa-paint-brush', 5, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (132, '发布新帖', 131, 'menu', '/admin/post/new', 'fa fa-circle-o', 9, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (133, '帖子列表', 131, 'menu', '/admin/post', 'fa fa-circle-o', 8, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (134, '回帖管理', 0, 'menu', '/admin/comment', 'fa fa-comment', 11, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (135, '回复我的', 134, 'menu', '/admin/comment/receive', 'fa fa-circle-o', 20, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (136, '我的回帖', 134, 'menu', '/admin/comment/send', 'fa fa-circle-o', 2, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (137, '板块管理', 0, 'menu', '/admin/category', 'fa fa-book', 6, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (138, '板块列表', 137, 'menu', '/admin/category', 'fa fa-circle-o', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (139, '新增板块', 137, 'menu', '/admin/category/new', 'fa fa-circle-o', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (140, '删除帖子', 133, 'button', '/admin/post/delete', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (141, '批量删除帖子', 133, 'button', '/admin/post/batchDelete', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (142, '编辑帖子', 133, 'page', '/admin/post/edit', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (143, '保存帖子', 132, 'button', '/admin/post/save', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (144, '恢复帖子', 133, 'button', '/admin/post/revert', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (145, '移到回收站', 133, 'button', '/admin/post/throw', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (146, '文件上传', 132, 'button', '/admin/file/upload', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (147, '保存板块', 139, 'button', '/admin/category/save', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (148, '编辑板块', 138, 'button', '/admin/category/edit', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (149, '删除板块', 138, 'button', '/admin/category/delete', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (150, '标签管理', 0, 'menu', '/admin/tag', 'fa fa-tag', 8, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (151, '标签列表', 150, 'menu', '/admin/tag', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (152, '删除标签', 151, 'button', '/admin/tag/delete', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (153, '所有回帖', 134, 'menu', '/admin/comment', 'fa fa-circle-o', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (154, '新增标签', 150, 'menu', '/admin/tag/new', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (155, '编辑标签', 151, 'page', '/admin/tag/edit', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (156, '保存标签', 154, 'button', '/admin/tag/save', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (157, '删除回帖', 153, 'button', '/admin/comment/delete', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (158, '批量删除回帖', 153, 'button', '/admin/comment/batchDelete', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (159, '后台回复回帖', 153, 'button', '/admin/comment/reply', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');
INSERT INTO `permission` VALUES (160, '全部标记已读', 135, 'button', '/admin/comment/readAll', '', 1, 0, 'admin', '2020-04-14 09:54:30', 'admin', '2020-04-14 09:54:30');

-- ----------------------------
-- Table structure for post
-- ----------------------------
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `user_id` bigint(20) NOT NULL COMMENT '发表用户的id',
  `post_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '文章类型',
  `post_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '文章标题',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '文章内容',
  `post_summary` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文章摘要',
  `post_thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文章缩略图',
  `post_status` int(11) NOT NULL COMMENT '0 已发布\r\n            ；1 草稿\r\n            ； 2 回收站',
  `post_views` bigint(20) NOT NULL COMMENT '文章访问量',
  `post_likes` int(11) NOT NULL COMMENT '点赞数量',
  `comment_size` int(11) NOT NULL COMMENT '回帖数量(冗余字段，加快查询速度)',
  `del_flag` int(1) NOT NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'admin' COMMENT '创建人用户名',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'admin' COMMENT '更新人用户名',
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK5hvavpcp1efcf6vxo09bhi9a7`(`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of post
-- ----------------------------
INSERT INTO `post` VALUES (1, 1, 'post', '为什么你考试会失败', '<p>考试失败带来的困惑<br>　　你有没有发现很多人考试就是考不及格?为什么?你的年龄已经不能适合当今的考试了。大凡45岁以上的男女,基本上考试很难过关了.因为现在都是电子监控,特别是路考,只能扣10分。<br>　　对于一个大年龄的你,无人如何都是一个考验。创业离不开阅历。<br>　　开车离不开年纪。不是说你笨.而是你的生理因素决定你了失败。<br>　　何况考试又紧张,血压会升高。你怎么能顺利通过考试昵?所以大年龄学车,自己累，教练更累。付出的成本肯定会高,你说学车有固定费用吗?<br>　　还有就是性格内向的男女,在失败面前,失去了信心,忧郁的心态，<br>　　导致你失败的考试命运。所以战胜自己,才是最关键的.现在考试这东西,说简单真的简单.而教练也就是那几句话。你听多了也许就会厌烦。可教练还是苦口婆心,一遍又一遍.可结果呢,你还是不能顺利通过考试.原因在哪里?<br>　　人最大的敌人就是自己,应试教育都是很死板的,就那几把方向。<br>　　所以考试考的就是心态.你心态放开了。考试基本就不是问题了。</p>', '考试失败带来的困惑　　你有没有发现很多人考试就是考不及格?为什么?你的年龄已经不能适合当今的考试了。大凡45岁以上的男女,基本上考试很难过关了.因为现在都是电子监控,特别是路考,只能扣10分。　　对于', NULL, 0, 12, 1, 2, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-22 14:55:30');
INSERT INTO `post` VALUES (2, 1, 'post', '老司机实用开车经验总结', '<p>老司机实用开车经验有哪些?开车总是容易出问题，有些是大问题需要专业维修，有些却是小问题自己就能解决，下面养生之道网为您总结了老司机实用开车经验，看看吧。</p><p>1、电动车窗的升降速度各个车门不一样。<br>&nbsp; &nbsp; &nbsp; &nbsp; 一般是由于玻璃升降轨道中进入了一些沙尘，使玻璃与沟槽之间的摩擦阻力变大，进而产生了这种结果。只要进行相应的清洗就可以解决问题了。</p><p>2、坡路停车时，有时 P 档位置变速不能搬动。<br>　　这是因为我们一般停车时都是先踩下制动后，将档把放倒 P 档位置，抬起制动踏板后，车辆会因为自重移动，导致变速器内的机械锁止 爪 受力卡在爪槽内所致，造成出现搬动档把时费力的感觉。</p><p><img src=\"/upload/2020/3/3102-150513112147.jpg\" style=\"width: 571px;\" class=\"fr-fic fr-dib fr-fil\"></p><p><br></p><p>正确的操作方法会避免这种情况出现。即：踩制动踏板，将变速杆放置在P档，拉起手动制动器，然后抬起制动踏板。</p><p><br></p><p>3、踩制动踏板时，变速杆处有 咔哒 的声音。<br>　　自动变速器的车辆一般都有防止误操作变速杆的功能。所以，在 P 档位置时不踩制动踏板变速杆是不能搬动的。变速杆处有 咔哒 的声音是电磁阀动作时发出的声音，每踩一次制动踏板，电磁阀都会发出声响。</p><p><br></p><p>4、空调开启时发动机转速不变化。<br>　　一般开空调时发动机的转速都有所提高，这是为了满足空调压缩机的负荷要求，保持发动机的怠速稳定。<br>　　但是，很多新款车辆配置的发动机，在开空调时发动机是不提高转速的，而是依靠增加发动机喷油器的喷油时间来保持发动机的怠速稳定。<br>　　所以，开空调时发动机不提速不一定就是故障。</p><p>5、自动变速器车辆不踩制动踏板变速杆不能搬动。<br>　　这是为了安全设计的一项功能，不是故障。</p><p>6、冬季车辆的天窗不能开启。<br>　　在冬季，在室外停放的车辆，因头天晚上车内温度较高致使飘落在天窗周围的冰雪溶化，而隔夜后，车辆的整体温度降低，溶化的雪水凝结成冰，所以，极易使天窗玻璃与密封胶框冻住。<br>　　如强行打开天窗易使天窗电动机及橡胶密封条损坏，因此要待车内温度上升确认解冻后再打开天窗。</p><p>......</p>', '老司机实用开车经验有哪些?开车总是容易出问题，有些是大问题需要专业维修，有些却是小问题自己就能解决，下面养生之道网为您总结了老司机实用开车经验，看看吧。1、电动车窗的升降速度各个车门不一样。&nbsp', NULL, 0, 1, 0, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (3, 1, 'post', '预防病毒从出行做起，从购买爱车荣威RX5', '<p>今天早上看新闻说意大利因为疫情的原因向我们国家求助，国务委员兼外长王毅应约同意大利外长迪马约通电话。迪马约表意大利疫情形势十分严峻，意政府正密切关注和学习中方抗疫的成功经验，采取有力举措阻止疫情扩散。面临医疗物资和设备短缺的困难，希中方帮助解决燃眉之急。</p><p><img src=\"/upload/2020/3/11.jpg\" style=\"width: 370px;\" class=\"fr-fic fr-dib fr-fil\"></p>', '今天早上看新闻说意大利因为疫情的原因向我们国家求助，国务委员兼外长王毅应约同意大利外长迪马约通电话。迪马约表意大利疫情形势十分严峻，意政府正密切关注和学习中方抗疫的成功经验，采取有力举措阻止疫情扩散。', NULL, 0, 2, 0, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (4, 1, 'post', '补考4次 磕磕撞撞 科目二终于过了，不容易呐', '<p>第一次：2次机会都是挂在压右边线，紧张是一个原因，但是关键是我没完全掌握倒车原理，是我打方向打早了。给我感觉考场好像跟我练车的场地不一样的。总结后我发现其实是一样的，回来练习的时候我总结：要右后车轮刚进库角并且离库角一部宽的时候立刻打死方向</p><p>第二次：还是倒车，第一次机会倒进去了，但是后库出线，原来是我犯了一个大忌，没按我平时练车那样调座位，我怕踩不到离合，一下子把座位调前了，还有踩踩车不够坚决，车由于惯性后溜了一下。第二次机会，我又倒进去了，吸取前面的教训我这次停的挺好的。但是换挡的时候我换了三次前进档，那车竟然还倒退，最后引车员不耐烦的叫我下车回去了，最后打电话给教练教练把我臭骂了一顿，感觉好对不住教练。这次总结是：怎么练怎么考，记住平时练车的位置，我是离胸口一巴掌这样来记住这个位置，平时练习倒库的时候进库停车最好下车观察下车尾有没出线或者车头有进库，一般是左后视镜遮住横线停车，因为车内和车外的视角不一样，然后记住这个位置考试就不会犯错了。那个换挡的问题，教练分析的原因是可能我考试紧张换挡的时候用力过猛，然后考试车的档位很松就很容易换成倒档，教练一开始教我科二的时候就说了3遍我换挡的问题，只怪我没听进去。</p><p>第三次：这次本来信心满满的，以为自己必过，但是我又错了。<br>第一次机会我倒库，打方向盘的时候才发现我看不到库角，我立刻把头埋下来都看不到，我心想完了，果然打死方向晚了，压左库角了，这次与其说引车员坏，还不如自己认栽好了，没调好后视镜就草草启动了。第二次机会我调好后视镜再启动倒库没问题。<br>心想自己终于可以考4项了，因为前面都挂在倒库，我前面的两个女孩子都及格了，最后一个轮到我，引车员选了6号道，我心里在骂那引车员，2，3，4道都没车不去，偏偏停了个6道，我当时感觉压力好大，上坡的时候我离合放多了，我准备对杆的时候才发现那杆好遥远的样子，完全对不上，过了个大概，又犯了一个错，先踩离合再踩刷车，加上速度，车完全飙过去了，电脑报超出50cm，好不容易的一次机会却输在起跑线上了，引车员然后叫我下车回去了，我下车看了下确实是超出50cm了。我打个电话给教练都不知道怎么跟他说，平时练习斜坡的时候我每次都是挺得很好。这次总结：起步的时候必须调座位，戴安全带，调后视镜，拉手刷，别以为前一批的人考过了后视镜不用调了，都要确保了才启动，只要调的时间不耗费太多引车员也不能怎样，挺多啰嗦下，他没权利判死刑滴。整个考试过程车速一定要慢，因为看点打方向只有车速慢的时候才有时间进行调整，车速快容易死火，斜坡停车的时候两脚一伸一起踩。<br><br>第四次：这次考试我已经很失望了，教练都对我无语了，练车的时候说报名不久的学员40多岁的阿姨，练车的时间没你长科二都一次性过了，你一个年轻小伙子还经常骑车有运动爱好怎么还补考那么多次我实在不明白。其实这次我花费很多精力总结了下，暗下决心要好好研究下，之前我听教练的说的练车方法，自己还在网上看了教程和视频，搞得当初教练说什么我都模模糊糊。这次我叫教练把倒车入库和侧方位的方法重新教我一遍，然后上网把每步为什么这么做的原理弄清楚然后才去练车，感觉还不放心，这两项练习的时候还把我同事叫上帮我看线，同时我网上把A考场的场地视频都看了一遍，然后我晚上睡觉的之前都会在脑海模拟自己在考试，每个场景每个点该干什么，我都走一遍流程，这样之后我感觉心里有底了。考前教练还带我去总部考场兜两圈，他说换个环境给我练下，看环境变化对我影响有多大，还真的感谢教练那么关心照顾。1点多排队进去验证等约考，我是第2个考倒库，我前面的一个学员是压边线挂了一次，还有一次机会倒进去了，出来停车的时候连车保险杠都没到边线就停车了，我那车的学员都惊呆了，他还说他教练是这么教他的，跟引车员在一边理论，引车员不理他。第二次到我了，我心里默念：调座位，戴安全带，调后视镜，拉手刷，换倒档，怎么练车怎么考试，上车后发现，妈呀，这车跟我上几次考的不一样，座位踏下去的，前后和高低根本调不了，算了不管那么多了不调了，可能有点心理阴影，我把后视镜调了2遍，然后倒库一次性过了，下车后松了一口气，跟我一车的后面2个学员倒库也没问题。到4项，考试顺序跟倒库顺序相反，由于第一个人倒库挂掉了，所以我是最后一个考，我在车上看路边绿叶去了，没看他们考试，因为每个人练车的方法不一样，我看他们考试有可能会受影响。前面2个都及格了，到我了，斜坡引车员挺得很好，停的是第4个道，太感谢他了，但是方向盘好像往右偏了1/8，我回正了下，怕车身不正我就把方向盘往左打了一点，不求那30cm了，只求不压线就好，A考场我结合2个方法看斜坡就是:边上第三根铁柱对准左手肘和车的右雨刮点过一点对杆，到点两脚一伸，电脑报&ldquo;车身离边线超30cm，定点小于50cm&rdquo;，松了一口气，到侧方位，最后打死的时候晚了点，其实我不知道是我打方向盘慢了还是怎样，车离右边还剩一指宽，最后车身刚好切到左边线的时候我就踩刷车了，不敢再进了，看电脑没报什么，我心里默念好险，换挡出去继续，建议左后轮快压边线的时候（大概10cm）左打死，因为等压到的时候才打，如果打方向盘的速度慢的话很容易右边压线。<br><br>最后s弯道，直角都没问题，终于听到久违的&ldquo;考试结束，成绩合格&rdquo;，心里感觉轻松很多。<br><br>4次考试总结：<span style=\"color: rgb(226, 80, 65);\">上车调座位，戴安全带，调后视镜，拉手刷，车速要慢，养成好习惯；记住教练说的每句话，最好做笔记，练车的时候有问题要多问教练，不怕有问题最怕没问题，脸皮要厚，心要细；要理解机动车原理，要弄明白教练教导练车方法</span><br>的原理，脑子模拟几遍考试，这样心里才有底，不然草草去考试就浪费时间和金钱。<br>方法和原理：<br>倒车入库<br>车未起步的时候方向盘向右打一圈+1/4回来一点，挂倒档启动车，看右后视镜；看车轮能否进库口，如果窄，回半圈，如果宽不用管，当右后轮快进库口的时候向右打死，可以不必打死；然后看左后视镜，当左边边线全部出来，立刻回正方向盘（看到底线立刻回正，不用等车身平衡），等后视镜下方完全遮住前方横线，立刻踩刷车(必须坚决,否则后库出线)。出去的时候肩膀出横线立刻向左打一圈又1/4回来一点（要保证左后轮出了库口），保持方向盘不动，等横线与离后视镜15厘米平衡停车。<br><br>个人理解：跟网上很多方法相比，我觉得教练的这个方法很灵活，如果理解透了，倒库基本90%能倒进去，关键要理解几个关键点：<br><br>1.如何判断车右后轮和库角有大概一步宽的距离？这个得多练才能找感觉，我是感觉只有车练多了才能感觉出车在倒退接近库角的运动轨迹的趋势，感觉宽多打点方向，感觉窄就回方向，但是窄的话顶多回半圈，还不够基本上没救了回压右库角<br><br>2.什么时候右打死？右后轮刚好进库就可以打，但是我一般是右打死回一点点方向，因为我感觉方向盘打死，整个车身就快速往一摆这样很容易压线。<br><br>3.什么时候回正？看到左边线完全刚好露出的时候立刻回正，不用等车身和左边线平衡，因为打方向盘需要时间，等平衡就晚了，容易造成车身不正。<br><br>4.车身不正如何修复？一句话，车速要慢，后视镜看车身离边线哪边宽方向盘就往哪边打，车身与线平衡回正方向<br><br>侧方位：<br>首先要追好边线路30cm停车，先挂倒车档倒车，从右后视镜里看车门把与前库的那条横线延长线，当那条横线延长线在车门把的中间的位置，向右打1又8分之一圈，然后看左后视镜左后轮上拱盖进库边线立即回方向，继续看左后轮，当左后轮离库边线10CM（教练好像是说这个距离，我不记得了，我就是自己看那个位置）时向左打死<br><br>个人理解：网上还有&ldquo;右打死，左打死&ldquo;的方法我没试过，我要做听教练话的好孩子，哈哈，教练说侧方位每个点位打方向盘的时机都要很坚决，不能犹豫，如果晚了就没得像倒库那样可以救<br><br>，看点打方向要多练然后记住这个点位，因为每个人的身高、车型、车速、打方向盘的速度等不一样，所以说方法不重要，重要的是要理解原理。<br><br><br><br>斜坡：<br>A考场感觉对杆6道好遥远，感觉对第三根铁柱子靠谱些，当然车练的熟悉了，到那个点就自然感觉出来，我还得修炼呐，哈哈<br><br>S弯：<br>这个简单，进去的时候保证人在中间，然后转弯的时候保证车头盖尾部1/4不出弯道，轮子基本不会压线。<br><br>直角：<br>S弯出来的时候尽量去追好右边线，如果怕压线，就拿车头盖的最右边去对边线也行，教练叫我左后视镜一出内线就打死，我是结合2个方法：后视镜车出内线和车头盖盖住最前面边线。</p>', '第一次：2次机会都是挂在压右边线，紧张是一个原因，但是关键是我没完全掌握倒车原理，是我打方向打早了。给我感觉考场好像跟我练车的场地不一样的。总结后我发现其实是一样的，回来练习的时候我总结：要右后车轮刚', NULL, 0, 1, 0, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (5, 1, 'post', '一个星期才能去驾校一次，什么时候才能考科目二', '<p>一个星期才能去驾校一次，什么时候才能考科目二</p><p><img src=\"/upload/2020/3/xiaojianmao.gif\" style=\"width: 100px;\" class=\"fr-fic fr-dib fr-fil\"></p>', '一个星期才能去驾校一次，什么时候才能考科目二', NULL, 0, 5, 1, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-23 14:52:43');
INSERT INTO `post` VALUES (6, 1, 'post', '今天刚在广州番禺的化龙东考完科目三 一把过！！', '<table cellpadding=\"0\" cellspacing=\"0\"><tbody><tr><td><p>今天刚在广州番禺的化龙东考完科目三&nbsp;一把过！！因为之前在典典这学到了好多考点&nbsp;而且发现网上并没有太多的关于化龙东考场的帖子&nbsp;特此发一条帖子感谢典典&nbsp;也想帮助到其他要考化龙东的朋友们！！<br>首先这条路真的是很少很少车！！考试的时候 有种马路是我家开的错觉。所以大家可以很放心 路很新 没有什么大的坡度 坑 啥的 基本考完灯光和靠边停车的出了大路都是过的啊！！车很新，内部很干净，很舒服！化龙东好像基本都是新款捷达 只有两部传祺（我抽到的是传祺）<br>好的废话少说&nbsp;先说说考试流程：模拟灯光-靠边停车-右转-超车-通过人行横道-掉头-通过学校-通过路口-加减档-通过巴士-会车-左转弯加调头-直线行驶-变更车道-终点[表情][表情]&nbsp;楼主是下午考的&nbsp;昨天教练带着我们四个来到这练了一下午（两点几到五点多）每人平均练了三圈&nbsp;考前来练练真的很有效啊！！今早也是七点多到&nbsp;练到九点半，每人两圈（十点要开始考试啰！要清场了）<br>考场旁边只要不要站太近都是可以看别人考试的 楼主发现有很多同学都在灯光挂的 好可惜啊！！所以千万要记熟灯光 考试的时候不要发呆 有好几个朋友估计是太紧张了发懵 发出指令过五秒都不知道要打灯 就这样可惜地挂了。。。关于灯光 上午考的同学说 要等到语音播完你再打灯 不然电子信号不好感应不到 你就不好办了<br>要不紧不慢 气定心闲 不！要！紧！张！考完灯光就要开始起步了 打左灯 按喇叭 看看左右镜地下的线的距离 挂一档 关手刹，慢慢松开离合。车头很多是没有科目二那个几号车的圆圈的 很多高个子也表示也看不到车头！但是为了让大家追线 你可以发现道路中间是有一点点或者是一沓沓油漆渍 用方向盘对着它们 就可以追线了 语音开始提示起步完成，请靠边停车，就开始打右灯，看镜等三秒，就可以停车了。停好之后的起步同样步骤，打灯喇叭看镜挂挡手刹！假如考试时前方有别的车在考，可以先变到左道，再变回右道进行右转！对了 不知道捷达如何 我考试的传祺的灯很容易跳灯！我打左灯的时候会自己跳回去！超车、变更车道的时候它突然又复灯了，监考员看了我一眼，我立马又补回去，简直是扶着灯光变道的。 好在车好开 不然真是鸡毛鸭乱啊<br>右转出去之后&nbsp;加加油门&nbsp;升到二档&nbsp;走一小段开始超车&nbsp;超完车&nbsp;直行通过路口之后&nbsp;可以先打左灯自己变一条道&nbsp;为前方的调头做好准备！以防慌张有些同学要连续变两条道的！掉头改一档通过会比较稳定，但有同学用二档也能过&nbsp;不熄火&nbsp;就看你怎么选择了！！通过学校&nbsp;巴士站这些虽然没有人&nbsp;但是也可以装装样子看看镜&nbsp;速度适当降一些&nbsp;看看人行道有没有人&nbsp;给监考员看到你是有注意这一点的！加减档&nbsp;它会语音降到一档&nbsp;加到二档&nbsp;然后说加减档完成[表情]到后面会车之后&nbsp;先自行打灯向左变一条道&nbsp;为后面的左转弯调头做准备！到语音提示前方左转弯请自行选择车道&nbsp;记得打灯！！控好离合&nbsp;因为这个调头弯很宽很宽&nbsp;你晚一点打方向也没问题！为了后面的直线行驶做准备&nbsp;给足够的距离拉直部车！！走完直线行驶一般都没有问题的了&nbsp;然后就是变更车道&nbsp;终点[表情]<br>抽到化龙东的朋友真的是很幸运的啊！！社会车少 考试车新 路面平整 空气好 离合油门很好踩 所以最根本的就是自己要放松！！不要紧张！把平时训练的状态拿出来 就当作是只是做一次给引车员看而已！虽然楼主也很紧张 早几天前一想到考车就心慌 今天中午考试前也吃不下饭 还反胃吐了一些水但是后来还是塞了一点下去 不停安慰自己 科目三只是咱人生中一件微不足道的事情！有什么好值得你连饭都吃不好呢！啰啰嗦嗦那么多 希望能对日后考化龙东的朋友有些帮助！祝大家都能顺顺利利拿到驾照！安安心心地开车上路！最后！谢谢宝典！</p></td></tr></tbody></table>', '今天刚在广州番禺的化龙东考完科目三&nbsp;一把过！！因为之前在典典这学到了好多考点&nbsp;而且发现网上并没有太多的关于化龙东考场的帖子&nbsp;特此发一条帖子感谢典典&nbsp;也想帮助到其', NULL, 0, 0, 0, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (7, 1, 'post', '科目一必过，必过，加油！科目一过不了我就该好好面壁思过了。', '<p>科目一必过，必过，加油！科目一过不了我就该好好面壁思过了。</p><p><img src=\"/upload/2020/3/1122.jpg\" style=\"width: 509px;\" class=\"fr-fic fr-dib fr-fil\"></p>', '科目一必过，必过，加油！科目一过不了我就该好好面壁思过了。', NULL, 0, 1, 0, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (8, 1, 'post', '像我这样一个星期就只能去两三次驾校，什么时候才能考科目二啊！郁闷死', '<p>像我这样一个星期就只能去两三次驾校，什么时候才能考科目二啊！郁闷死</p>', '像我这样一个星期就只能去两三次驾校，什么时候才能考科目二啊！郁闷死', NULL, 0, 2, 0, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (9, 1, 'post', '教练不在副驾驶座，结果...', '<p>肿么办啊？？？？？有人遇到过吗</p><p><img src=\"/upload/2020/3/666.jpg\" style=\"width: 541px;\" class=\"fr-fic fr-dib fr-fil\"></p>', '肿么办啊？？？？？有人遇到过吗', NULL, 0, 2, 0, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (10, 1, 'post', '总是心不在焉，被训醒了，刻苦努力到深夜只为拿证！', '<p>总是心不在焉，被训醒了，刻苦努力到深夜只为拿证！</p><p><img src=\"/upload/2020/3/222.jpg\" style=\"width: 353px;\" class=\"fr-fic fr-dib fr-fil\"></p>', '总是心不在焉，被训醒了，刻苦努力到深夜只为拿证！', NULL, 0, 5, 0, 1, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (11, 1, 'post', '前台视频展现', '<p>早上去了一趟岑村A考场，回来把考场的照片拿出来跟大家交流分享，以下还有关于岑村A考场的注意事项，如果对考场有问题，也可以回帖问我噢！<br><br>上坡定点与起步</p><p><img src=\"/upload/2020/3/2211.jpg\" style=\"width: 468px;\" class=\"fr-fic fr-dib fr-fil\"></p>', '早上去了一趟岑村A考场，回来把考场的照片拿出来跟大家交流分享，以下还有关于岑村A考场的注意事项，如果对考场有问题，也可以回帖问我噢！上坡定点与起步', NULL, 0, 4, 1, 1, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-24 15:24:48');
INSERT INTO `post` VALUES (12, 1, 'post', '风景', '<table cellpadding=\"0\" cellspacing=\"0\"><tbody><tr><td><p>科目四考的是文明驾驶和正常行驶，虽然考试难度是有的，但是相对于科目二和科目三，那就是小巫见大巫了，并且只要掌握了小技巧，顺利通过是没有问题的。<br><br>一&nbsp;、判断对错：<br>1、不准你做的事情都是对的(不准、不得、不应、不能、严禁、紧止、应当)<br>2、让对方先走的都是对的(减速让行、停车让行、礼让通行、减速避让)<br>3、慢的都是对的(缓慢通过、减速、平稳、逐渐、慢慢通过、将速度降低、匀速下降)<br>4、观察的都是对的(提前观察、仔细观察、认真观察、瞭望)<br>5、安全的都是对的(间断轻踏、保证安全、确保安全、安全通过)<br>6、不听话的都是错的(只要、可、可以)<br>7、快的都是错的(立即、直接、加速通过、迅速通过、急打方向盘、猛打方向盘、迅速向左右躲避、紧急制动)<br><br>二、灯光使用：<br>开启远光灯的全是错的，有危险警报闪光灯的全对，进入高速开左转向灯，驶离高速开右转向灯，&ldquo;进环岛不开灯，驶离环岛开右转向灯&rdquo;。<br><br>三、上下坡制动：<br>下坡提前，上坡推迟。上下坡会车：下坡让上坡。<br><br>四、车轮侧滑问题：<br>前车轮侧滑往相反方向打转向，后车轮侧滑往相同方向打转向，总结就是前反后同，如果题目没说前后轮，都当后轮侧滑算。<br><br>五、ABS防抱死系统：<br>具有保持转向能力，可用力踏制动踏板，紧急制动的同时转向会发生侧滑，制动距离不会缩短和延长未安装ABS系统要轻踏或间歇踩踏制动转向助力装置出现问题不能继续行驶需停车检查原因。<br><br>六、警告标志：<br>机动车在道路上发生故障或者发生交通事故，妨碍交通又难以移动的，应当按照规定开启危险报警闪光灯并在车后50米至100米处设置警告标志，夜间还应当同时开启示廓灯和后位灯。高速公路上要在车后150米外设置警告标志。<br><br>七、关于等待：<br>同向只有1、2条机动车道停车等待，3条车道可以缓慢通过无需等待。<br><br>八、变换车道：<br>有障碍让无障碍方，靠山让不靠山的先走路口50米内不得变更车道。<br><br>九、制动：<br>行车制动踏板：脚刹车驻车制动：手刹车发动机制动：低档行驶加速踏板：油门。<br><br>十、交警手势，交警脸看向你有三种情况：<br>1、正面看你左手平举-停车，正面看你右手平举上下摆动-减速慢行;<br>2、交警脸转左侧看你-左转弯;<br>3、交警脸转右侧看你-右转弯。交警脸看左右车道不看你时-停车等待。交警脸看左边车道且左手上下摆动-左转弯待转(即使你看懂了手势，也要注意，只有交警脸是对着你的，才是对你说的) 十一、最高速度： 没有限速标志、标线的城市道路的最高速度为30公里，道路的最高速度为40公里，只有一条机动车道的城市道路最高50公里，只有一条机动车道的公路最高为70公里。<br><br>十二、关于261、145、520：<br>261：能见度在200米以下，最高车速为60公里，最小车距为100米。<br>145：能见度在100米以下，最高车速为40公里，最小车距为50米。<br>520：能见度在50米以下，最高车速为20公里，从最近出口驶出高速公路。<br><br>十三、口诀吊2撤3醉5逃终身：<br>吊销机动车证的为二年，撤消机动车证的为三年，以醉酒吊销五年，因逃跑而吊销是终身，叫&ldquo;吊二撤三醉五逃终身&rdquo;。<br><br>十四、不得停车：<br>交叉路口、铁道路口、急转路、宽度不足4米的窄路、桥梁、陡坡、隧道以及距离上述地点50米以内的路段不得停车;<br>公共汽车站、急救站、加油站、消防栓或者消防队门前以及距离上述地点30米以内的路段，不得停车。<br><br>十五、扣12分：<br>驾驶中型以上载货载客汽车、校车、危险品运输车在高速、城市快速路上超速20%以上或在其他道路超速50%以上;驾驶其他机动车超速50%以上。<br><br>十六、扣6分：<br>驾驶中型以上载货载客汽车、校车、危险品运输车在高速、城市快速路上超速未达20%或在其他道路超速20%以上未达50%，其他机动车超速20%以上未达50%。<br><br>十七、记6分的：<br>1、机动车驾驶证被暂扣期间驾驶机动车的;<br>2、驾驶机动车违反道路交通信号灯通行的;<br>3、驾驶机动车违法占用应急车道行驶的;<br>4、低能见度气象条件下驾驶机动车在高速公路上不按规行驶的;<br>5、驾驶机动车运载超限物品未按指定时间、路线、速度行驶或未悬挂明显标志的;<br>6、驾驶机动车载运危险品未按指定时间、路线、速度行驶或未悬挂警示标志并采取的安全措施的;<br>7、以隐瞒欺骗手段补领机动车驾驶证的; 8.驾驶机动车不按照规定避让校车的。<br><br>十八、点火锁开关档位设置方式。其含义是：<br>LOCK：切断电源，锁定方向盘;<br>ACC：接通附件电源(比如收音机等附件);<br>ON：接通除起动机外的全车全部电源;<br>START、接通起动机电源，起动发动机。 (起动后松手钥匙，会自动弹回ON档位)<br><br>十九、车道限速：<br>如果有同方向有3条的车道，最右侧的速度范围为60公里到90公里，中间的为90公里到110公里，最左侧的为110公里到120公里。<br><br>二十、申请准驾车型要求：<br>1、申请小型汽车、小型自动挡汽车、残疾人专用小型自动挡载客汽车、轻便摩托车准驾车型的申请人年龄应在18周岁以上、70周岁以下;<br>2、申请低速载货汽车、三轮汽车、普通三轮摩托车、普通二轮摩托车、轮式自行机械车准驾车型的申请人年龄应在18周岁以上，60周岁以下;<br>3、申请城市公交车、大型货车、无轨电车、有轨电车准驾车型的申请人年龄应在20周岁以上，50周岁以下。<br><br>这些小技巧你记住了吗？现在科目四对你来说是不是小菜一碟了呢~</p></td></tr></tbody></table>', '科目四考的是文明驾驶和正常行驶，虽然考试难度是有的，但是相对于科目二和科目三，那就是小巫见大巫了，并且只要掌握了小技巧，顺利通过是没有问题的。一&nbsp;、判断对错：1、不准你做的事情都是对的(不准', NULL, 0, 10, 1, 2, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-24 15:19:38');
INSERT INTO `post` VALUES (13, 1, 'post', '科目二视频', '<p><span class=\"fr-video fr-dvb fr-draggable fr-fvl\" contenteditable=\"false\" draggable=\"true\"><video class=\"fr-draggable\" controls=\"\" src=\"/upload/2020/3/1-4_redis特性目录.mp4\" style=\"width: 600px;\">您的浏览器不支持 HTML5 视频。</video></span></p>', '您的浏览器不支持 HTML5 视频。', NULL, 0, 23, 0, 2, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (14, 1, 'post', '11', '<p>111</p>', '111', NULL, 2, 0, 0, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (15, 1, 'post', '222', '<p>22</p>', '22', NULL, 0, 0, 0, 0, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');
INSERT INTO `post` VALUES (16, 1, 'post', '22', '<p>222</p>', '222', NULL, 0, 8, 0, 1, 0, 'admin', '2020-04-14 08:38:56', 'admin', '2020-04-14 08:38:56');

-- ----------------------------
-- Table structure for post_category_ref
-- ----------------------------
DROP TABLE IF EXISTS `post_category_ref`;
CREATE TABLE `post_category_ref`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '文章和板块关联id',
  `post_id` bigint(20) NOT NULL COMMENT '关联的文章id',
  `cate_id` bigint(20) NOT NULL COMMENT '关联的板块id',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人用户名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新人用户名',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `del_flag` int(1) NOT NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FKatntuqmrfdi01vecyyi24arus`(`cate_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of post_category_ref
-- ----------------------------
INSERT INTO `post_category_ref` VALUES (1, 1, 1, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (2, 2, 1, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (3, 3, 1, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (4, 4, 1, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (5, 5, 5, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (6, 6, 1, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (7, 7, 1, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (8, 8, 5, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (9, 9, 5, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (10, 10, 1, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (13, 13, 6, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (14, 14, 1, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (15, 15, 2, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (16, 16, 3, NULL, '2020-04-14 09:35:18', NULL, '2020-04-14 09:36:02', 0);
INSERT INTO `post_category_ref` VALUES (17, 12, 2, NULL, '2020-04-24 14:28:29', NULL, '2020-04-24 14:28:29', 0);
INSERT INTO `post_category_ref` VALUES (18, 11, 1, NULL, '2020-04-24 14:29:42', NULL, '2020-04-24 14:29:42', 0);

-- ----------------------------
-- Table structure for post_tag_ref
-- ----------------------------
DROP TABLE IF EXISTS `post_tag_ref`;
CREATE TABLE `post_tag_ref`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '文章和标签关联id',
  `post_id` bigint(20) NOT NULL COMMENT '文章id',
  `tag_id` bigint(20) NOT NULL COMMENT '标签id',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建人用户名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新人用户名',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `del_flag` int(1) NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `FK_Relationship_5`(`tag_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of post_tag_ref
-- ----------------------------
INSERT INTO `post_tag_ref` VALUES (1, 2, 24, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (2, 2, 25, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (3, 2, 26, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (4, 3, 27, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (5, 6, 11, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (6, 6, 22, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (7, 7, 9, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (8, 8, 21, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (9, 8, 10, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (10, 9, 32, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (11, 9, 33, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (12, 9, 11, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (13, 10, 34, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (14, 10, 21, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (18, 13, 36, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (19, 13, 10, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);
INSERT INTO `post_tag_ref` VALUES (20, 15, 38, NULL, '2020-04-14 08:40:54', NULL, '2020-04-14 08:40:54', 0);

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色名称：admin，author，subscriber',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '描述：管理员，作者，订阅者',
  `level` int(1) NOT NULL COMMENT '角色级别',
  `is_register_default` int(1) NOT NULL DEFAULT 0 COMMENT '用户注册默认角色',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '发布人用户名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '发表时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新人用户名',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  `del_flag` int(1) NULL DEFAULT 0 COMMENT '删除状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, 'admin', '管理员', 10, 0, NULL, '2020-04-13 16:18:58', NULL, '2020-04-13 16:18:58', 0);
INSERT INTO `role` VALUES (2, 'user', '用户', 5, 1, NULL, '2020-04-13 16:19:21', NULL, '2020-04-20 10:39:52', 0);
INSERT INTO `role` VALUES (19, 'school_user', '板块负责人', 7, 0, NULL, '2020-04-13 16:20:00', NULL, '2020-04-23 15:21:31', 0);

-- ----------------------------
-- Table structure for role_permission_ref
-- ----------------------------
DROP TABLE IF EXISTS `role_permission_ref`;
CREATE TABLE `role_permission_ref`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '角色与权限关联id',
  `role_id` bigint(20) NOT NULL COMMENT '角色id',
  `permission_id` bigint(20) NOT NULL COMMENT '权限id',
  `del_flag` int(1) NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '发布人用户名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '发表时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新人用户名',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1883 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role_permission_ref
-- ----------------------------
INSERT INTO `role_permission_ref` VALUES (1777, 2, 1, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1778, 2, 106, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1779, 2, 6, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1780, 2, 7, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1781, 2, 131, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1782, 2, 133, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1783, 2, 140, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1784, 2, 141, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1785, 2, 142, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1786, 2, 144, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1787, 2, 145, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1788, 2, 132, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1789, 2, 143, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1790, 2, 146, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1791, 2, 134, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1792, 2, 153, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1793, 2, 157, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1794, 2, 158, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1795, 2, 159, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1796, 2, 136, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1797, 2, 135, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1798, 2, 160, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1799, 2, 120, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1800, 2, 82, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1801, 2, 83, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1802, 1, 1, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1803, 1, 106, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1804, 1, 6, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1805, 1, 7, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1806, 1, 131, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1807, 1, 133, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1808, 1, 140, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1809, 1, 141, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1810, 1, 142, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1811, 1, 144, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1812, 1, 145, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1813, 1, 132, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1814, 1, 143, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1815, 1, 146, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1816, 1, 137, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1817, 1, 138, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1818, 1, 148, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1819, 1, 149, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1820, 1, 139, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1821, 1, 147, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1822, 1, 150, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1823, 1, 151, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1824, 1, 152, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1825, 1, 155, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1826, 1, 154, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1827, 1, 156, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1828, 1, 134, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1829, 1, 153, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1830, 1, 157, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1831, 1, 158, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1832, 1, 159, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1833, 1, 136, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1834, 1, 135, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1835, 1, 160, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1836, 1, 70, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1837, 1, 126, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1838, 1, 72, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1839, 1, 73, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1840, 1, 74, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1841, 1, 75, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1842, 1, 76, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1843, 1, 91, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1844, 1, 127, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1845, 1, 111, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1846, 1, 92, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1847, 1, 93, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1848, 1, 94, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1849, 1, 95, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1850, 1, 128, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1851, 1, 110, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1852, 1, 96, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1853, 1, 97, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1854, 1, 98, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1855, 1, 120, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1856, 1, 82, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1857, 1, 83, 0, NULL, '2020-04-14 13:28:46', NULL, '2020-04-14 13:28:46');
INSERT INTO `role_permission_ref` VALUES (1858, 19, 1, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1859, 19, 106, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1860, 19, 6, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1861, 19, 7, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1862, 19, 131, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1863, 19, 133, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1864, 19, 140, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1865, 19, 141, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1866, 19, 142, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1867, 19, 144, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1868, 19, 145, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1869, 19, 132, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1870, 19, 143, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1871, 19, 146, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1872, 19, 134, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1873, 19, 153, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1874, 19, 157, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1875, 19, 158, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1876, 19, 159, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1877, 19, 136, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1878, 19, 135, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1879, 19, 160, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1880, 19, 120, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1881, 19, 82, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');
INSERT INTO `role_permission_ref` VALUES (1882, 19, 83, 0, NULL, '2020-04-23 15:21:31', NULL, '2020-04-23 15:21:31');

-- ----------------------------
-- Table structure for tag
-- ----------------------------
DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '标签id',
  `tag_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '标签名称',
  `del_flag` int(1) NOT NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '发布人用户名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '发表时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新人用户名',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tag
-- ----------------------------
INSERT INTO `tag` VALUES (1, '111', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (2, 'Java', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (3, 'PHP', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (4, '1112', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (5, '驾考报名、上海学车', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (6, '文章', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:20:12');
INSERT INTO `tag` VALUES (7, '图文', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:20:27');
INSERT INTO `tag` VALUES (8, '222', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (9, 'java', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:21:03');
INSERT INTO `tag` VALUES (10, '前端开发', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:21:16');
INSERT INTO `tag` VALUES (11, '后端开发', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:21:26');
INSERT INTO `tag` VALUES (12, '风景', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:21:45');
INSERT INTO `tag` VALUES (13, '吐槽', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (14, '22', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (15, '111', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (16, '1', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (17, '11', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (18, '2', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (19, '分享', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (20, '学习', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:22:09');
INSERT INTO `tag` VALUES (21, '考试', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (22, '心得', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (23, '经验分享', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (24, '时事', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:22:48');
INSERT INTO `tag` VALUES (25, '文化', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:23:17');
INSERT INTO `tag` VALUES (26, '搞笑', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:24:26');
INSERT INTO `tag` VALUES (27, '支援', 1, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (28, '驾考', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (29, '社团', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:24:47');
INSERT INTO `tag` VALUES (30, '美食', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:25:15');
INSERT INTO `tag` VALUES (31, '事故', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (32, '教学', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:25:35');
INSERT INTO `tag` VALUES (33, '毕业', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:25:51');
INSERT INTO `tag` VALUES (34, '历史', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-24 14:26:25');
INSERT INTO `tag` VALUES (35, '视频', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (36, '1', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');
INSERT INTO `tag` VALUES (37, '111', 0, NULL, '2020-04-14 08:42:31', NULL, '2020-04-14 08:42:31');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `user_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名',
  `user_display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户显示的名称',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户密码',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户邮箱',
  `user_avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户头像',
  `user_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户说明',
  `login_enable` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否禁止登录（true/flase）',
  `login_error` int(11) NULL DEFAULT NULL COMMENT '登录错误次数',
  `login_last` datetime(0) NULL DEFAULT NULL COMMENT '最后一次登录时间',
  `status` int(1) NULL DEFAULT NULL COMMENT '0 正常\r\n            ；1 禁用\r\n            ；2 已删除',
  `del_flag` int(1) NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'admin' COMMENT '发布人用户名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '发表时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'admin' COMMENT '更新人用户名',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_user_email`(`user_email`) USING BTREE,
  UNIQUE INDEX `uk_user_name`(`user_name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'admin', '管理员', '533ac0bac8514c35e29c4b1fbbd8ef9a', '098805@qq.com', '/static/images/avatar/1.jpeg', NULL, 'true', 0, '2020-04-24 14:14:44', 0, 0, 'admin', '2020-04-13 16:25:17', 'admin', '2020-04-13 16:27:50');

-- ----------------------------
-- Table structure for user_role_ref
-- ----------------------------
DROP TABLE IF EXISTS `user_role_ref`;
CREATE TABLE `user_role_ref`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户与角色关联id',
  `user_id` bigint(20) NOT NULL COMMENT '用户id',
  `role_id` bigint(20) NOT NULL COMMENT '角色id',
  `del_flag` int(1) NULL DEFAULT 0 COMMENT '删除状态：1删除，0未删除',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '发布人用户名',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '发表时间',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新人用户名',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_role_ref
-- ----------------------------
INSERT INTO `user_role_ref` VALUES (1, 1, 1, 0, NULL, '2020-04-13 16:28:43', NULL, '2020-04-13 16:28:43');

SET FOREIGN_KEY_CHECKS = 1;
